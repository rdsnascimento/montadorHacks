# Montador Hacks
Implementação da máquina hipotética Hacks. Trabalho da disciplina de Programação de Sistemas

Etapa 1:
Criar máquina virtual.

**O que se está fazendo ?**

- [x] Entender a Máquina Virtual
- [x] Criar as Classes
- [ ] Emular as Instruções
- [ ] ~~Confirmar com o Grupo~~