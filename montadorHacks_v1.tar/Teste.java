public class Teste{

	public static void main(String[] args){

		final int testMemorySize = 16;

		HacksVirtualMachine hvm = new HacksVirtualMachine(testMemorySize);
		
		if ( !hvm.loadRom("teste_01.rom") )
			System.out.println("Falha ao ler arquivo!");
		
		// debug
		else {
			for(int j = 0; j < testMemorySize; j++)
				System.out.println("rom[" + j + "] = " + hvm.rom[j] );



			for(int i = 0; i < testMemorySize; i++) {				
				hvm.exec();

			}
		}

		/*
			boolean condition = true;
			while(condition)
				condition = hvm.exec();

		}

		*/
	}
}