/*
	Soma as medidas dos lados de um triangulo qualquer e retorna o perímetro
*/

int main(){

	int a = 2,b = 2,c = 3;	

	int d = a + b + c;

	return 0;
}

/*
	agora será compilado para testeCodigo_01.asm
*/